from tkinter import *
class Gui():
    # controlador de janelas
    def raise_frame(frame):
        frame.tkraise()

    def __init__(self):
        #criando a janela
        self.window = Tk()
        #frames
        self.login_j = Frame(self.window)
        self.centros = Frame(self.window)
        self.chamados = Frame(self.window)
        for frame in (self.login_j, self.centros, self.chamados):
            frame.grid(row=0, column=0, sticky='nesw')

        # criando os elementos
        # ========================Tela de Login =====================
        self.txtLogin = StringVar()
        self.txtSenha = StringVar()

        self.img_logo = PhotoImage(file='images/img_user.png')
        self.img_lab = Label(self.login_j, image=self.img_logo)
        self.login_text = Label(self.login_j, text='Login:')
        self.login_input = Entry(self.login_j)
        self.password_text = Label(self.login_j, text='Senha:')
        self.password_input = Entry(self.login_j, show='*')
        self.login_btn = Button(self.login_j, text='Entrar')
        self.error_box = Label(self.login_j,text="Usuário ou senha incorretos!")

        self.criadores = Label(self.login_j,text="Sistema de Chamados")

        # ========================Tela de Centros ==================
        self.txtNome = StringVar()
        self.txtSetor = StringVar()
        self.txtContato = StringVar()

        self.img_usr = PhotoImage(file='images/user2.png')
        self.img_user = Label(self.centros, image=self.img_usr)
        self.label_name = Label(self.centros, text="Nome: {}".format(self.txtNome))
        self.label_setor = Label(self.centros, text='Setor: {}'.format(self.txtSetor))
        self.label_contato = Label(self.centros, text='Contato: {}'.format(self.txtContato))
        # menus normal
        self.btn_altera = Button(self.centros, text='Perfil')
        self.btn_chamados = Button(self.centros, text='Chamados')
        self.btn_abrir = Button(self.centros, text='AbrirChamado')
        self.btn_bloqueados = Button(self.centros, text='Bloqueados')
        self.btn_abertos = Button(self.centros, text='Abertos')

        # menu admin
        self.default = StringVar(self.window)
        self.default.set("Chamados")
        self.btn_altera = Button(self.centros, text='Perfil')
        self.btn_chamados_a = OptionMenu(self.centros, self.default, "Chamados", "     Criar     ", "Pesquisar", command="")
        self.btn_gerencia_a = Button(self.centros, text=' Gerenciar ')

        # tela onde é exibida os dados
        self.listaChamados = Listbox(self.centros, width=81)
        self.scrollChamados = Scrollbar(self.centros)

        # Associando a Scrollbar com a Listbox...
        self.listaChamados.configure(yscrollcommand=self.scrollChamados.set)
        self.scrollChamados.configure(command=self.listaChamados.yview)

        self.fonte = ('Futura BQ', 14)
        self.fonte_btn = ('Futura BQ', 14)
        self.fonte_erro = ('Verdana', 3)
        self.fonte_dados_centro = ('Futura BQ', 11)
        self.fonte_dados_centro_b = ('Futura BQ', 11, 'bold')
        self.fonte_btn_centro = ('Futura BQ', 14)
        self.fonte_creditos = ('Futura BQ', 10)

    # posicionando
    def configure_layout(self):
        # ========================Tela de Login =====================
        self.img_lab.grid(row=0, column=0, columnspan=2, sticky='nesw', padx=160, pady=40)
        self.login_text.grid(row=1, column=0, pady=1, sticky='e')
        self.login_input.grid(row=1, column=1, pady=1, sticky='w')
        self.password_text.grid(row=2, column=0, pady=1, sticky='e')
        self.password_input.grid(row=2, column=1, pady=1, sticky='w')
        self.login_btn.grid(row=3, column=0, columnspan=2, pady=4)
        #self.error_box.grid(row=4,column=0,columnspan=4)

        # ========================Tela de Centros ==================
        self.img_user.grid(row=0, column=0, rowspan=3)
        self.label_name.grid(row=0, column=1, sticky='w', columnspan=4)
        self.label_setor.grid(row=1, column=1, sticky='w')
        self.label_contato.grid(row=2, column=1, sticky='w', columnspan=4)
        if (True):
            # menu simples
            self.btn_altera.grid(row=3, column=0, columnspan=2, sticky='w')  # perfil
            self.btn_chamados.grid(row=3, column=1, sticky='w')  # chamados
            self.btn_abrir.grid(row=3, column=2, sticky='w')  # abrir
            self.btn_bloqueados.grid(row=3, column=3, sticky='w')  # bloqueados
            self.btn_abertos.grid(row=3, column=4, sticky='w')  # abertos
        else:

            self.btn_altera.grid(row=3, column=0, columnspan=2, sticky='w')  # perfil
            self.btn_chamados_a.grid(row=3, column=1, sticky='w')  # chamados
            self.btn_bloqueados.grid(row=3, column=3, sticky='w')  # bloqueados
            self.btn_abertos.grid(row=3, column=4, sticky='w')  # abertos
            self.btn_gerencia_a.grid(row=3, column=2, sticky='w')  # Gerenciar
        # tela de dados
        self.listaChamados.grid(row=4, column=0, columnspan=5, padx=0, pady=0, sticky='w')
        self.scrollChamados.grid(row=4, column=4, padx=3, sticky='eNS')

        self.criadores = Label(self.centros,text="Sistema de Chamados \n Desenvolvido por William Thiago e Jorge Siqueira")
        self.criadores.configure(fg="#510FBA");
        self.criadores.grid(columnspan=5, pady=193)
    #estilizando
    def configure_sizes(self):
        # estilizando
        # ========================Tela de Login =====================
        self.login_input.configure(font=self.fonte, fg="#510FBA", width=12)
        self.password_input.configure(font=self.fonte_btn, fg="#510FBA", width=12)
        self.login_text.configure(font=self.fonte, fg="#510FBA")
        self.password_text.configure(font=self.fonte, fg="#510FBA")
        self.login_btn.configure(font=self.fonte_btn, fg="#510FBA", relief='groove', width=17)
        self.error_box.configure(font=self.fonte,fg="red")
        self.criadores.configure(fg="#510FBA");

        # ========================Tela de Centros ===================
        self.label_name.configure(font=self.fonte_dados_centro_b, fg="#510FBA")
        self.label_setor.configure(font=self.fonte_dados_centro, fg="#510FBA")
        self.label_contato.configure(font=self.fonte_dados_centro, fg="#510FBA")
        self.btn_altera.configure(font=self.fonte_btn_centro, fg="white", relief='groove', bg='#510FBA')
        self.btn_chamados.configure(font=self.fonte_btn_centro, fg="white", relief='groove', bg='#510FBA')
        self.btn_abrir.configure(font=self.fonte_btn_centro, fg="white", relief='groove', bg='#510FBA')
        self.btn_bloqueados.configure(font=self.fonte_btn_centro, fg="white", relief='groove', bg='#510FBA')
        self.btn_abertos.configure(font=self.fonte_btn_centro, fg="white", relief='groove', bg='#510FBA')
        self.btn_chamados_a.configure(font=self.fonte_btn_centro, fg="white", relief='groove', bg='#510FBA')
        self.btn_chamados_a["menu"].config(font=self.fonte_btn_centro, fg="white", relief='groove', bg='#510FBA')
        self.btn_gerencia_a.configure(font=self.fonte_btn_centro, fg="white", relief='groove', bg='#510FBA')
    #dados da janela
    def configureWindow(self):
        # dados da janela
        self.window.title('Sistema de chamados')
        self.window.iconbitmap(r'images/favicon.ico')
        self.window.geometry('500x500')
        self.window.resizable(0, 0)

    def run(self):
        self.configure_layout()
        self.configure_sizes()
        self.configureWindow()
        self.window.mainloop()

