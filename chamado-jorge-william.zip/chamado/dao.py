import sqlite3 as sql

class BdAccess():
    database = "clientes.db"
    conn = None
    cur = None
    connected = False

    def connect(self):
        "realiza conexão com o banco de dados"
        try:
            BdAccess.conn = sql.connect(BdAccess.database)
            BdAccess.cur = BdAccess.conn.cursor()
            BdAccess.connected = True
        except sqlite3.Error as error:
            print("Erro no banco de dados: ", error)

    def disconnect(self):
        BdAccess.conn.close()
        BdAccess.connected = False

    def execute(self, sql, parms=None):
        if BdAccess.connected:
            if parms == None:
                BdAccess.cur.execute(sql)
            else:
                BdAccess.cur.execute(sql, parms)
            return True
        else:
            return False

    def fetchall(self):
        return BdAccess.cur.fetchall()

    def persist(self):
        if BdAccess.connected:
            BdAccess.conn.commit()
            return True
        else:
            return False

    def alimenta(self):
        #tabelas dos chamados
        self.execute("CREATE TABLE IF NOT EXISTS pessoa (id INTEGER PRIMARY KEY , nome TEXT, tipo_usuario INTEGER, login TEXT, senha TEXT, sexo TEXT, centro TEXT, departamento TEXT)")
        self.execute(
            "CREATE TABLE IF NOT EXISTS chamado (id INTEGER PRIMARY KEY , id_cliente INTEGER, data_abertura TEXT, data_encerramento TEXT, proprietario TEXT, status INTEGER,prioridade INTEGER)")
        self.execute(
            "CREATE TABLE IF NOT EXISTS resposta (id INTEGER PRIMARY KEY , cliente TEXT, tipo_resposta int, data_resposta TEXT, assunto TEXT, descricao TEXT)")
        #tabelas dos centros
        self.execute(
            "CREATE TABLE IF NOT EXISTS faculdade (id INTEGER PRIMARY KEY , nome TEXT)")
        self.execute(
            "CREATE TABLE IF NOT EXISTS centros (id INTEGER PRIMARY KEY, id_chefe INTEGER, id_faculdade INTEGER, nome TEXT)")
        self.execute(
            "CREATE TABLE IF NOT EXISTS departamento (id INTEGER PRIMARY KEY,id_centros INTEGER, nome TEXT,sala  INTEGER, telefone TEXT)")

        #cadastrando a primeira faculdade
        self.faculdade = "UFRR"
        self.centro = "DCC"
        self.chefe = 1
        self.execute("INSERT INTO faculdade VALUES(NULL, ?)", (self.faculdade,))
        #inserindo primeiro departamento
        self.execute("INSERT INTO centros VALUES(NULL, ?,?,?)", (self.faculdade,self.chefe,self.centro,))

        #primeiro usuario
        self.execute("INSERT INTO  pessoa VALUES(NULL, ?,?,?,?,?,?,?)", ("William Thiago Almeida Silva",2,"william.thiago", "123", "M","1","1",))


class PessoaDAO():
    def __init__(self):
        "Quando a aplicação for executada pela primeira vez, cria-se o banco de dados e um super user"
        self.bd = BdAccess()
        self.bd.connect()
        self.bd.alimenta()
        self.bd.persist()
    def buscaPessoa(self,login,senha):
        rows = None
        try:
            self.bd.execute("SELECT * FROM pessoa WHERE login=? AND senha=?",(login,senha))
            rows = self.bd.fetchall()
        except sql.Error as error:
            print("Falha ao tentar selecionar os registros")
            print("Classe da exceção: ", error.__class__)
            print("Exceção é ", error.args)
            raise sql.Error()
        return rows
    def buscaDep(self,id_departaento):
        rows = None
        try:
            self.bd.execute("SELECT nome FROM centros WHERE id=?",(id_departaento))
            rows = self.bd.fetchall()
        except sql.error as error:
            print("Falha ao tentar selecionar os registros")
            print("Classe da exceção: ", error.__class__)
            print("Exceção é ", error.args)
            raise sql.Error()
        return rows


