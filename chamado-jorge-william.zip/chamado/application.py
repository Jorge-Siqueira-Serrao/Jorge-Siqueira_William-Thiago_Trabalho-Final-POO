from GUI import Gui
from dao import PessoaDAO
from tkinter import END
from model import Pessoa

class Controller():
    def __init__(self):
        self.gui = Gui()
        self.dao = PessoaDAO()
        self.selected = None  # passoa selecionada
        self.currentPessoa = Pessoa()

    def autentica(self,user="",password=""):
        self.user = user
        self.password = password
        rows = self.dao.buscaPessoa(user,password)
        print("Search Result: ", rows)
        if(rows != []):
            rows2 = self.dao.buscaDep(rows[0][6])
            print("teste: ", rows2[0][0])
            self.__fill_current_pessoa(rows[0][0],rows[0][1],rows[0][2],rows[0][3],rows[0][4],rows[0][5],rows2[0][0],rows[0][7])
            # chama a próxima tela
            self.callTelaCentro()
        else:
            self.gui.error_box.grid(row=4,column=0,columnspan=4) #exibe label de erro
            print("fail")

    #preenchendo os dados da pessoa
    def __fill_current_pessoa(self,id="",nome="",tipo="",login="",senha="",sexo="",centro="",departamento=""):
        self.currentPessoa.id = id
        self.currentPessoa.nome = nome
        self.currentPessoa.tipo = tipo
        self.currentPessoa.login = login
        self.currentPessoa.senha = senha
        self.currentPessoa.sexo = sexo
        self.currentPessoa.centro = centro
        self.currentPessoa.departamento = departamento

    def callTelaCentro(self):
        print(self.currentPessoa.nome)
        self.gui.label_name.config(text=("Nome:", self.currentPessoa.login))
        self.gui.label_setor.config(text=("Setor: {}".format(self.currentPessoa.centro)))
        self.gui.label_contato.config(text=("Contato: {}".format(self.currentPessoa.login)))
        self.gui.centros.tkraise()

    # login system
    def systemEvents(self):
        self.gui.login_btn.configure(command= lambda:[self.autentica(self.gui.login_input.get(), self.gui.password_input.get())])

    def start(self):
        #run command
        self.gui.login_j.tkraise()
        self.systemEvents()
        self.gui.run()





Controller().start()



