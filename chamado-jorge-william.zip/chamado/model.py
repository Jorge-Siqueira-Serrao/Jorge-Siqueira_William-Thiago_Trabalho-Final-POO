class Pessoa:
    def __init__(self, nome="", login="", senha="", sexo="",centro="",departamento=""):
        self.nome = nome
        self.login = login
        self.senha = senha
        self.sexo = sexo
        self.centro =centro
        self.departamento = departamento

    def __str__(self):
        print(self.nome, self.sobrenome, self.email, self.cpf)






